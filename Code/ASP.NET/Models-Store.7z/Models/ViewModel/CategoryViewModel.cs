﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace logicProject.Models.ViewModel
{
    public class CategoryViewModel
    {
        public string id;
        public string category;
    }
}