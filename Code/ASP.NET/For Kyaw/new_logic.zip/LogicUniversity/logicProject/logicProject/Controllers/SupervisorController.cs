﻿using logicProject.Models.DBContext;
using logicProject.Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace logicProject.Controllers
{
    public class SupervisorController : Controller
    {
        // GET: Supervisor
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ApproveForm(int id)
        {

            List<AdjustmentDetail> cart_list;

            using (LogicEntities db = new LogicEntities())
            {
                cart_list = db.AdjustmentDetail.Where(item => item.AdjustmentId == id).ToList();
                Adjustment req = db.Adjustment.Where(x => x.AdjustmentId == id).SingleOrDefault();

                ViewData["cart_list"] = cart_list;
                ViewData["adjustment"] = req;
                db.SaveChanges();
            }



            return View();
        }

        [HttpPost]
        public ActionResult ApproveForm(string approve, string reject, string remarks, int id)
        {

            using (LogicEntities db = new LogicEntities())
            {
                Adjustment rd = db.Adjustment.Find(id);



                if (approve == "Approve")
                {
                    rd.Status = approve;
                    rd.Remark = remarks;

                    db.SaveChanges();

                    List<AdjustmentDetail> adjustmentDetails = db.AdjustmentDetail.Where(x => x.AdjustmentId == id).ToList();
                    foreach (var detail in adjustmentDetails)
                    {
                        var res = db.Product.SingleOrDefault(p => p.ProductId == detail.ProductId);
                        var res2 = db.StockTransaction.SingleOrDefault(p => p.ProductId == detail.ProductId);

                        if (res != null)
                        {
                            res.Qty += detail.Qty;
                            db.SaveChanges();
                        }

                        if (res2 != null)
                        {
                            res2.Qty += detail.Qty;
                            db.SaveChanges();
                        }
                    }
                }
                else if (reject == "Reject")
                {
                    rd.Status = reject;
                    rd.Remark = remarks;
                    db.SaveChanges();
                }
            }
            return RedirectToAction("ViewVoucherList");
        }

        public ActionResult ChangeStatus()
        {
            Adjustment adjustment = new Adjustment();


            return View();
        }

        public ActionResult ViewVoucherList()
        {
            List<Adjustment> cart_list;

            using (LogicEntities db = new LogicEntities())
            {

                cart_list = db.Database.SqlQuery<Adjustment>("select distinct a.* from Adjustments a join AdjustmentDetails ad on a.AdjustmentId=ad.AdjustmentId where (select sum(x.TotalPrice) from AdjustmentDetails x where x.AdjustmentId=a.AdjustmentId group by x.AdjustmentId) < 250").ToList();

                db.SaveChanges();
            }
            ViewData["cart_list"] = cart_list;

            return View();
        }
       

    }
}