﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using logicProject.Models;
using logicProject.Models.DBContext;
using logicProject.Models.EF;

namespace logicProject.Controllers
{
    public class clerkController : Controller
    {
        // GET: clerk
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult create_form ()
        {
            StoreStaff user = (StoreStaff)Session["user"];
            using (LogicEntities db = new LogicEntities())
            {
                db.Adjustment.RemoveRange(db.Adjustment.Where(x => x.Status == "temp").ToList());
                db.SaveChanges();
            }
            int form_number = 1;
            using (LogicEntities db = new LogicEntities())
            {
                if (db.Adjustment.AsEnumerable().ToList().Count != 0)
                {
                    form_number = db.Adjustment.AsEnumerable().Max(p => p.AdjustmentId);
                    Debug.WriteLine("***************** before" + form_number);
                    form_number = form_number + 1;
                    Debug.WriteLine("***************** after" + form_number);
                }
                else
                {
                    form_number = 1;
                }
            }

            Debug.WriteLine("*****************" + form_number);
            using (LogicEntities db = new LogicEntities())
            {
                db.Adjustment.Add(new Adjustment { AdjustmentId = form_number, Remark="--", AdjustedDate=DateTime.Now.Date, StaffId = user.StaffId , Status = "temp" });
                db.SaveChanges();
            }

            List<ProductViewModel> items;

            int num_new;
            using (LogicEntities db = new LogicEntities())
            {

                //items = db.Product.Select(p => new Product
                //{
                //    ProductId = p.ProductId,
                //    Category = p.Category,
                //    Description = p.Description,
                //    Qty = p.Qty
                //}).ToList();

                //items = db.Product.ToList();
                items = getProducts(db);
                num_new = db.Adjustment.AsEnumerable().Max(p => p.AdjustmentId);

            }

            ViewData["form_number"] = num_new;
            ViewData["items"] = items;
            ViewData["msg"] = " "+ num_new;

            return View();

        }

        private List<ProductViewModel> getProducts(LogicEntities db)
        {
            List<ProductViewModel> items = (from p in db.Product
                     join pod in db.PurchaseOrderDetail on p.ProductId equals pod.ProductId
                     join po in db.PurchaseOrder on pod.OrderId equals po.OrderId
                     join spd in db.SupplierProduct on po.SupplierId equals spd.SupplierId
                     where spd.ProductId == pod.ProductId
                     select new ProductViewModel
                     {
                         ProductId = p.ProductId,
                         Category = p.Category,
                         Description = p.Description,
                         Qty = p.Qty,
                         UnitPrice = spd.Price
                     }).ToList<ProductViewModel>();

            items.Insert(0, new ProductViewModel
            {
                Description = "None",
                UnitPrice = 0
            });

            return items;
        }

        public ActionResult addnew(AdjustmentDetail form_detail_obj)
        {
            if(string.IsNullOrEmpty(form_detail_obj.ProductId))
            {
                return RedirectToAction("addcart");
            }

            using (LogicEntities db = new LogicEntities())
            {
                List<AdjustmentDetail> temp = db.AdjustmentDetail.ToList();
               
                int form_details_num = (db.AdjustmentDetail.AsEnumerable().ToList().Count == 0) ? 1 : (db.AdjustmentDetail.AsEnumerable().Max(p => p.AdjustmentDetailId)) + 1 ;

                AdjustmentDetail old_rec_to_update = (from f in db.AdjustmentDetail
                                                           where f.ProductId == form_detail_obj.ProductId && f.AdjustmentId == form_detail_obj.AdjustmentId
                                                           select f).FirstOrDefault();
                if (old_rec_to_update != null)
                {
                    old_rec_to_update.Qty += form_detail_obj.Qty;
                }
                else
                {
                    Debug.WriteLine("____________" + form_details_num + "##" + form_detail_obj.AdjustmentId);
                    db.AdjustmentDetail.Add(new AdjustmentDetail { AdjustmentDetailId = form_details_num, AdjustmentId = form_detail_obj.AdjustmentId, ProductId = form_detail_obj.ProductId, Qty = Convert.ToInt32(form_detail_obj.Qty), UnitPrice = form_detail_obj.UnitPrice, TotalPrice = form_detail_obj.TotalPrice, reason = form_detail_obj.reason });
                }

                db.SaveChanges();
            }

            return RedirectToAction("addcart");
        }

        public ActionResult addcart()
        {
            StoreStaff user = (StoreStaff)Session["user"];
            int form_number;
            List<AdjustmentDetail> cart_list;
            List<ProductViewModel> items;
            using (LogicEntities db = new LogicEntities())
            {
                //items = db.Product.ToList();
                items = getProducts(db);
                form_number = db.Adjustment.AsEnumerable().Max(p => p.AdjustmentId);
                cart_list = db.AdjustmentDetail.Include(ad => ad.Product).Where(x => x.AdjustmentId == form_number).ToList();
            }

            ViewData["cart_list"] = cart_list;
            ViewData["form_number"] = form_number;
            ViewData["items"] = items;
            return View("create_form");
        }


        public ActionResult submitrequest()
        {
            int emp_id = int.Parse(Request.Form["emp_id"]);
            int form_number = int.Parse(Request.Form["form_number"]);

            using (LogicEntities db = new LogicEntities())
            {
                Adjustment old_rec_to_update = (from f in db.Adjustment
                                                     where f.StaffId == emp_id && f.AdjustmentId == form_number && f.Status == "temp"
                                                     select f).FirstOrDefault();
                if (old_rec_to_update != null)
                {
    
                    old_rec_to_update.Status = "Pending";

                }
                db.SaveChanges();
            }

            return View("index");
        }
    }

    
}