﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using logicProject.Models;
using logicProject.Models.DBContext;
using logicProject.Models.EF;

namespace logicProject.Controllers
{
    public class VoucherController : Controller
    {
        // GET: Voucher
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AdjustmentForm(string id)
        {
            
            List<AdjustmentDetail> form_cart;
            Adjustment form;
            List<Product> products;
            Product product;            
            


            return View();
        }
    }
}