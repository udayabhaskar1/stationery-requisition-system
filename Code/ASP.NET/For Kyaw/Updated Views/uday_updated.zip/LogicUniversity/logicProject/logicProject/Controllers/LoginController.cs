﻿using logicProject.Models.DBContext;
using logicProject.Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace logicProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            //if (Session["user"] != null)
            //{
            //    Session.Remove("user");
            //}
            return View();
        }

        [HttpPost]
        public ActionResult login(string Username, string Password)
        {
            StoreStaff user;

            using (LogicEntities db = new LogicEntities())
            {
                user = (from e in db.StoreStaff
                        where e.Username == Username
                        select e).FirstOrDefault();
                //Debug.WriteLine(user.Password);
            }
            if (user != null)
            {
                if (Password.Equals(user.Password))
                {
                    if (user.StaffType == "Manager")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("ViewVoucherList", "Manager");
                    }
                    else if (user.StaffType == "Supervisor")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("ViewvoucherList", "Supervisor");
                    }
                    else if (user.StaffType == "Clerk")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("Index", "Clerk");
                    }
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");

        }      


        
        public ActionResult democall(ItemModel itemModel)
        {

            Dictionary<string, string> dict = new Dictionary<string, string>();


            Dictionary<string, string> dict0 = new Dictionary<string, string>
            {
                { "category", "Select Category" },
                { "value", "0" }
            };

            Dictionary<string, string> dict1 = new Dictionary<string, string>
            {
                { "category", "Clip" },
                { "value", "1" }
            };

            Dictionary<string, string> dict2 = new Dictionary<string, string>
            {
                { "category", "Envelope" },
                { "value", "2" }
            };

            Dictionary<string, string> dict3 = new Dictionary<string, string>
            {
                { "category", "Eraser" },
                { "value", "3" }
            };

            Dictionary<string, string> dict4 = new Dictionary<string, string>
            {
                { "category", "Exercise" },
                { "value", "4" }
            };
            Dictionary<string, string> dict5 = new Dictionary<string, string>
            {
                { "category", "File" },
                { "value", "5" }
            };
            Dictionary<string, string> dict6 = new Dictionary<string, string>
            {
                { "category", "Pen" },
                { "value", "6" }
            };
            Dictionary<string, string> dict7 = new Dictionary<string, string>
            {
                { "category", "Puncher" },
                { "value", "7" }
            };
            Dictionary<string, string> dict8 = new Dictionary<string, string>
            {
                { "category", "Pad" },
                { "value", "8" }
            };
            Dictionary<string, string> dict9 = new Dictionary<string, string>
            {
                { "category", "Paper" },
                { "value", "9" }
            };
            Dictionary<string, string> dict10 = new Dictionary<string, string>
            {
                { "category", "Ruler" },
                { "value", "10" }
            };
            Dictionary<string, string> dict11 = new Dictionary<string, string>
            {
                { "category", "Scissors" },
                { "value", "11" }
            };
            Dictionary<string, string> dict12 = new Dictionary<string, string>
            {
                { "category", "Tape" },
                { "value", "12" }
            };
            Dictionary<string, string> dict13 = new Dictionary<string, string>
            {
                { "category", "Sharpener" },
                { "value", "13" }
            };
            Dictionary<string, string> dict14 = new Dictionary<string, string>
            {
                { "category", "ShortHand" },
                { "value", "14" }
            };
            Dictionary<string, string> dict15 = new Dictionary<string, string>
            {
                { "category", "Stapler" },
                { "value", "15" }
            };
            Dictionary<string, string> dict16 = new Dictionary<string, string>
            {
                { "category", "Tacks" },
                { "value", "16" }
            };
            Dictionary<string, string> dict17 = new Dictionary<string, string>
            {
                { "category", "Tparency" },
                { "value", "17" }
            };
            Dictionary<string, string> dict18 = new Dictionary<string, string>
            {
                { "category", "Tray" },
                { "value", "18" }
            };
            List<Dictionary<string, string>> catList = new List<Dictionary<string, string>> {
                dict0, dict1, dict2, dict3, dict4,dict5,dict6,dict7,dict8,dict9,dict10,dict11,dict12,dict13,dict14,dict15,dict16,dict17,dict18
            };

            Dictionary<string, string> mon0 = new Dictionary<string, string>
            {
                {"month", "Select Month" },
                { "value","0" }
            };

            Dictionary<string, string> mon1 = new Dictionary<string, string>
            {
                {"month", "Jan" },
                { "value","1" }
            };
            Dictionary<string, string> mon2 = new Dictionary<string, string>
            {
                {"month", "Feb" },
                { "value","2" }
            };
            Dictionary<string, string> mon3 = new Dictionary<string, string>
            {
                {"month", "Mar" },
                { "value","3" }
            };

            Dictionary<string, string> mon4 = new Dictionary<string, string>
            {
                {"month", "Apr" },
                { "value","4" }
            };

            Dictionary<string, string> mon5 = new Dictionary<string, string>
            {
                {"month", "May" },
                { "value","5" }
            };

            Dictionary<string, string> mon6 = new Dictionary<string, string>
            {
                {"month", "Jun" },
                { "value","6" }
            };

            Dictionary<string, string> mon7 = new Dictionary<string, string>
            {
                {"month", "Jul" },
                { "value","7" }
            };

            Dictionary<string, string> mon8 = new Dictionary<string, string>
            {
                {"month", "Aug" },
                { "value","8" }
            };

            Dictionary<string, string> mon9 = new Dictionary<string, string>
            {
                {"month", "Sep" },
                { "value","9" }
            };

            Dictionary<string, string> mon10 = new Dictionary<string, string>
            {
                {"month", "Oct" },
                { "value","10" }
            };

            Dictionary<string, string> mon11 = new Dictionary<string, string>
            {
                {"month", "Nov" },
                { "value","11" }
            };

            Dictionary<string, string> mon12 = new Dictionary<string, string>
            {
                {"month", "Dec" },
                { "value","12" }
            };

            List<Dictionary<string, string>> monList = new List<Dictionary<string, string>>
            {
                mon0,mon1, mon2, mon3, mon4, mon5, mon6, mon7, mon8, mon9, mon10, mon11, mon12
            };

            
            int cat = 0;
            int mon = 0;

            if(itemModel != null)
            {
                if (!string.IsNullOrEmpty(itemModel.SelectedCategory))
                {
                    cat = int.Parse(itemModel.SelectedCategory);
                }
                mon = itemModel.SelectedMonth;
            }

            List<string> values_ = new List<string>();
            List<string> keys_ = new List<string>();

            if(cat != 0 && mon != 0)
            {
                JObject obj = JObject.Parse(demo(cat, mon).Result);

                JObject result = (JObject)obj["result"];

                foreach (var i in result)
                {
                    Debug.WriteLine(i);
                    values_.Add((string)i.Value);
                    Debug.WriteLine(((string)i.Value));
                    keys_.Add((string)i.Key);
                    Debug.WriteLine(((string)i.Key));

                }
            }

                ViewBag.QTYS = values_;
                ViewBag.MONS = keys_;                
                ViewBag.CatList = catList;
                ViewBag.MonList = monList;
            


            return View(new ItemModel());
        }

        public static async  Task<string> demo(int item, int mont)
        {
            string content="";
            using (var httpClient = new HttpClient())
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("http://127.0.0.1:3000");

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                // List data response.
                HttpResponseMessage response = client.GetAsync("?id="+item+"&mon="+mont).Result;  // Blocking call! Program will wait here until a response is received or a timeout occurs.
                if (response.IsSuccessStatusCode)
                {
                    // Parse the response body.
                    content = await response.Content.ReadAsStringAsync();
                    //dataObjects = Convert.ToString(response.Content);  //Make sure to add a reference to System.Net.Http.Formatting.dll
                    Debug.WriteLine(content);
                }
                else
                {
                    Debug.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }               
            }
            return content;
        }

        public ActionResult dummy( string MONID, string ITEMID)
        {
            List<string> values_ = new List<string>();
            List<string> keys_ = new List<string>();
            Dictionary<string, string> dict_ = new Dictionary<string, string>();
            ViewBag.QTYS = values_;
            ViewBag.MONS = keys_;
            ViewBag.dict = dict_;
            ViewBag.monthid = (MONID == null)?  "1" : MONID;
            ViewBag.itemid = (ITEMID == null) ? "1" : ITEMID;
            ViewBag.status = false;
            return View();
        }

        public ActionResult dummy_(string ITEMID, string MONID)
        {
            
            List<string> values_ = new List<string>();
            List<string> keys_ = new List<string>();
            Dictionary<string, string> dict_ = new Dictionary<string, string>();

            int cat = int.Parse(ITEMID);
            int mon = int.Parse(MONID);
            if (cat != 0 && mon != 0)
            {
                JObject obj = JObject.Parse(demo(cat, mon).Result);

                JObject result = (JObject)obj["result"];

                foreach (var i in result)
                {
                    Debug.WriteLine(i);
                    values_.Add((string)i.Value);
                    Debug.WriteLine(((string)i.Value));
                    keys_.Add((string)i.Key);
                    Debug.WriteLine(((string)i.Key));

                    dict_[(string)i.Key] = (string)i.Value;

                }
            }
           
            ViewBag.dict = dict_;
            ViewBag.monthid = MONID;
            ViewBag.itemid = ITEMID;
            ViewBag.status = true;

            return View("dummy", new { MONID = MONID, ITEMID = ITEMID });
            
        }
    }
}
