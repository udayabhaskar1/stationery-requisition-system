﻿using logicProject.Models.DBContext;
using logicProject.Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace logicProject.Controllers
{
    public class SupervisorController : Controller
    {
        // GET: Supervisor
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ApproveForm(int id)
        {

            List<AdjustmentDetail> cart_list;

            using (LogicEntities db = new LogicEntities())
            {
                cart_list = db.AdjustmentDetail.Where(item => item.AdjustmentId == id).ToList();
                db.SaveChanges();
            }
            ViewData["cart_list"] = cart_list;


            return View();
        }

        public ActionResult ChangeStatus()
        {
            Adjustment adjustment = new Adjustment();


            return View();
        }

        public ActionResult ViewVoucherList()
        {
            List<Adjustment> cart_list;

            using (LogicEntities db = new LogicEntities())
            {

                cart_list = db.Database.SqlQuery<Adjustment>("select distinct a.* from Adjustments a join AdjustmentDetails ad on a.AdjustmentId=ad.AdjustmentId where (select sum(x.TotalPrice) from AdjustmentDetails x where x.AdjustmentId=a.AdjustmentId group by x.AdjustmentId) < 250").ToList();

                db.SaveChanges();
            }
            ViewData["cart_list"] = cart_list;

            return View();
        }
       

    }
}