﻿using logicProject.Models.DBContext;
using logicProject.Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace logicProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            //if (Session["user"] != null)
            //{
            //    Session.Remove("user");
            //}
            return View();
        }

        [HttpPost]
        public ActionResult login(string Username, string Password)
        {
            StoreStaff user;

            using (LogicEntities db = new LogicEntities())
            {
                user = (from e in db.StoreStaff
                        where e.Username == Username
                        select e).FirstOrDefault();
                //Debug.WriteLine(user.Password);
            }
            if (user != null)
            {
                if (Password.Equals(user.Password))
                {
                    if (user.StaffType == "Manager")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("ViewVoucherList", "Manager");
                    }
                    else if (user.StaffType == "Supervisor")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("ViewvoucherList", "Supervisor");
                    }
                    else if (user.StaffType == "Clerk")
                    {
                        Session.Add("user", user);
                        return RedirectToAction("Index", "Clerk");
                    }
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");

        }
    }
}
