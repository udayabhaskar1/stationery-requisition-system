﻿using logicProject.Models.DBContext;
using logicProject.Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace logicProject.Controllers
{
    public class InventoryController : Controller
    {
        // GET: Inventory
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewInventory()
        {
            List<Product> items;

            using (LogicEntities db = new LogicEntities())
            {
                items = db.Product.ToList();       

            }

            ViewData["items"] = items;

            return View();
        }

        public ActionResult ViewLowStock()
        {

            List<Product> items;

            using (LogicEntities db = new LogicEntities())
            {
                items = db.Product.Where(item => item.Qty < item.ReorderLevel).ToList();
                db.SaveChanges();

            }

            ViewData["items"] = items;

            return View();

        }
    }
}